package com.example.administrator.ktour;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //back키 제어 시작
    boolean isClick = false;
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            isClick = false;
        }

    };

    @Override
    public void onBackPressed() {
        if (!isClick) {
            Toast.makeText(this, "다시 누르면 종료됩니다", Toast.LENGTH_SHORT).show();
            isClick = true;
            handler.sendEmptyMessageDelayed(0, 2000);
        } else {
            finish();
        }
    }
    //back키 제어 끝

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //button (updating)
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
        Button btn7 = findViewById(R.id.btn7);
        //Button btn8 = findViewById(R.id.btn8);

        // 클릭리스너 연결
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //명시적 인텐트
                Intent intent = new Intent(MainActivity.this,
                        kyoungBok_Activity.class);
                startActivity(intent);
                finish();
            }
        });


        //out of memory error 방지를 위한 백그라운드 설정 작업
        btn1.setBackgroundDrawable(new BitmapDrawable(getResources(),
                BitmapFactory.decodeResource(getResources(), R.drawable.kbok_main)));
        btn2.setBackgroundDrawable(new BitmapDrawable(getResources(),
                BitmapFactory.decodeResource(getResources(), R.drawable.changduk_main)));
        btn3.setBackgroundDrawable(new BitmapDrawable(getResources(),
                BitmapFactory.decodeResource(getResources(), R.drawable.duksu_main)));
        btn4.setBackgroundDrawable(new BitmapDrawable(getResources(),
                BitmapFactory.decodeResource(getResources(), R.drawable.kyounghee_main)));
        btn5.setBackgroundDrawable(new BitmapDrawable(getResources(),
                BitmapFactory.decodeResource(getResources(), R.drawable.changkyoung_main)));
        btn6.setBackgroundDrawable(new BitmapDrawable(getResources(),
                BitmapFactory.decodeResource(getResources(), R.drawable.jongmyo_main)));
        btn7.setBackgroundDrawable(new BitmapDrawable(getResources(),
                BitmapFactory.decodeResource(getResources(), R.drawable.unhyun_main)));
        //btn8.setBackgroundDrawable(new BitmapDrawable(getResources(),
        //        BitmapFactory.decodeResource(getResources(), R.drawable.ready_main)));

        //memory 해제

    }

    public void onDestroy(Button btn) {
        recycleView(btn);
    }

    private void recycleView(Button btn) {
        if(btn != null) {
            Drawable bg = btn.getBackground();
            if(bg != null && !((BitmapDrawable)bg).getBitmap().isRecycled()) {
                bg.setCallback(null);
                ((BitmapDrawable)bg).getBitmap().recycle();
                btn.setBackgroundDrawable(null);
            }
        }
    }
}
