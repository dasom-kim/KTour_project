package com.example.administrator.ktour;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class SplashActivity extends AppCompatActivity {

    Handler handler = new Handler();
    AnimationDrawable ani;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        LinearLayout layout = findViewById(R.id.splashAct);
        // 프레임 애니메이션
        ani = (AnimationDrawable) layout.getBackground();
        ani.start();

        // 3초 뒤 동작
        // 지금 화면을 꺼주지 않으면 back키 눌렀을 때 다시 나타남
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent =
                        new Intent(
                                SplashActivity.this,
                                MainActivity.class
                        );
                startActivity(intent);
                ani.stop();
                finish();
            }
        }, 3000);
    }
}
