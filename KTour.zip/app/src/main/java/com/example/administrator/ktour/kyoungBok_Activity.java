package com.example.administrator.ktour;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SlidingDrawer;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.LocationRequest;

import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;

import java.security.MessageDigest;
import java.util.ArrayList;

import static com.example.administrator.ktour.R.id.handle;
import static com.example.administrator.ktour.R.id.slidingdrawer;

public class kyoungBok_Activity extends AppCompatActivity
        implements MapView.OpenAPIKeyAuthenticationResultListener
        , MapView.MapViewEventListener
        , MapView.POIItemEventListener {

    int selected;
    TextView show;
    MapView mapView;
    ArrayList<palace_Data> list;
    int routeNumber = 1, all_Clicked = 1;
    Button eraser, reset, all, inform;

    //이동 경로 표시
    String selectedMarker = "";

    //back키 제어 시작
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(kyoungBok_Activity.this,
                MainActivity.class);
        startActivity(intent);
        finish();


        Log.e("back", "dd");
    }
    //back키 제어 끝

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kyoung_bok_);

        // 권한 얻어오기
        checkPermissions();

        // 지도에 표시될 대상의 위치 데이터 목록

        list = new ArrayList<>();
        list.add(new palace_Data(37.57857157866728, 126.977018993141,getText(R.string.kb_place1).toString()));//근정전
        list.add(new palace_Data(37.579000221695196, 126.97595016844447,getText(R.string.kb_place2).toString()));
        list.add(new palace_Data(37.57977508875224, 126.97603594250991,getText(R.string.kb_place3).toString()));
        list.add(new palace_Data(37.57911217348474, 126.97703240100586,getText(R.string.kb_place4).toString()));
        list.add(new palace_Data(37.57954825568845, 126.97705489998157,getText(R.string.kb_place5).toString()));
        list.add(new palace_Data(37.57994469632464, 126.97708646893682,getText(R.string.kb_place6).toString()));
        list.add(new palace_Data(37.580326921067396, 126.97810523481944,getText(R.string.kb_place9).toString()));
        list.add(new palace_Data(37.5823593311925, 126.9770449231481,getText(R.string.kb_place10).toString()));
        list.add(new palace_Data(37.583494374547584, 126.97610260376744,getText(R.string.kb_place11).toString()));
        list.add(new palace_Data(37.5826073868174, 126.9742326176402,getText(R.string.kb_place12).toString()));
        // list.add(new ShopData(37.583494374547584, 126.97610260376744,"집옥재"));
        // list.add(new ShopData(37.5826073868174, 126.9742326176402,"태원전"));
        // To do : 동궁, 소주방 추가 해야함

        show = findViewById(R.id.show);

        // 위치 정확도 향상
        LocationRequest lr = new LocationRequest();
        lr.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        lr.setInterval(5000);
        LocationManager lm =
                (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // 위치제공자, 통지 최소 시간(mSec), 통지 최소 거리(M)
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) !=
                        PackageManager.PERMISSION_GRANTED) {
            //Toast.makeText(this, "권한 승인 후 사용 가능", Toast.LENGTH_SHORT).show();
        } else {
            boolean isGPSEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if(isGPSEnabled) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 100, 1, mLocationListener);
            }
            boolean isNetworkEnabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if(isNetworkEnabled) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 100, 1, mLocationListener);
            }
        }

        mapView = new MapView(this);

        mapView.setMapViewEventListener(this);
        mapView.setOpenAPIKeyAuthenticationResultListener(this);
        mapView.setPOIItemEventListener(this);

        reset =  findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){

                if (mapView.getCurrentLocationTrackingMode() ==
                        MapView.CurrentLocationTrackingMode.TrackingModeOff)
                    mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOnWithHeading);
                else
                    mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOff);

            }
        });

        ViewGroup mapViewContainer = findViewById(R.id.map_view);
        mapViewContainer.addView(mapView);


//        MapPOIItem startMarker = new MapPOIItem();
//        startMarker.setItemName("출발지");

        eraser = findViewById(R.id.eraser);
        eraser.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                initRoute();
            }
        });

        all = findViewById(R.id.all);
        all.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                SlidingDrawer sd = findViewById(R.id.slidingdrawer);
                if (sd.isOpened()) {
                    Toast.makeText(kyoungBok_Activity.this, getText(R.string.error_text).toString(), Toast.LENGTH_LONG).show();
                    return;
                }

                if (all_Clicked % 2 == 0) all.setBackgroundResource(R.drawable.all_off_icon);
                else all.setBackgroundResource(R.drawable.all_icon);

                // all_Clicked 변수가 홀수면 꺼짐, 짝수면 켜짐 상태
                all_Clicked++;
                showItems();
            }
        });

        inform = findViewById(R.id.inform);

        inform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(kyoungBok_Activity.this , informActivity.class);
                startActivity(intent);
            }
        });

//        SlidingDrawer slidingdrawer = findViewById(R.id.slidingdrawer);
//        slidingdrawer.open();
    }
    private void showItems(){
        // 지도 표시 대상

        // 경복궁 위치로
        GpsInfo info = new GpsInfo(this);
        double latitude = info.getLatitude();
        double longitude = info.getLongitude();
//        double latitude = 37.57593689999999;
//        double longitude = 126.97681569999997;
        //mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(37.57593689999999, 126.97681569999997), true);

        for(int i = 0; i < list.size(); i++) {
            double lat = list.get(i).getLat();
            double lng = list.get(i).getLng();
            String name= list.get(i).getName();
            double distance = LocationUtil.distance(latitude, longitude, lat, lng, LocationUtil.METER);

            // 기존 아이템 지우기
            MapPOIItem[] item = mapView.findPOIItemByName(name);
            if (item != null && !selectedMarker.equals(name)) {
                mapView.removePOIItems(item); }
            //

            MapPOIItem shop = new MapPOIItem();
            shop.setItemName(name);
            // shop.setTag(i + 1000);
            shop.setShowDisclosureButtonOnCalloutBalloon(false);
            shop.setMapPoint(MapPoint.mapPointWithGeoCoord(lat, lng));
            shop.setMarkerType(MapPOIItem.MarkerType.CustomImage);
            //shop.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin);//만들고
            shop.setSelectedMarkerType(MapPOIItem.MarkerType.CustomImage);
            shop.setCustomSelectedImageResourceId(R.drawable.clicked_marker);
            // 100미터 이내,
            if(distance <= 100) {
                //shop.setMarkerType(MapPOIItem.MarkerType.BluePin);
                shop.setCustomImageResourceId(R.drawable.blue_marker);
                mapView.addPOIItem(shop);
            }
            else{
                if(all_Clicked%2==0) {//켜짐(짝수)
                    //shop.setMarkerType(MapPOIItem.MarkerType.YellowPin);
                    shop.setCustomImageResourceId(R.drawable.yellow_marker);
                    mapView.addPOIItem(shop);
                }
            }


        }

        selected = 0;
    }
    private void initRoute(){
        GpsInfo info = new GpsInfo(this);
        double lat = info.getLatitude();
        double lng = info.getLongitude();
        mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(37.57593689999999, 126.97681569999997), true);

        for(int i = 0; i < routeNumber; i++) {
            Log.e("Remove!", "tag id: "+i);
            MapPOIItem item = mapView.findPOIItemByTag(i);
            if(item != null)
                mapView.removePOIItem(item);
        }

        MapPOIItem marker = new MapPOIItem();
        marker.setItemName(getText(R.string.startSpot).toString());
        marker.setTag(0);
        marker.setShowDisclosureButtonOnCalloutBalloon(false);
        marker.setMapPoint(MapPoint.mapPointWithGeoCoord(lat, lng));
        marker.setMarkerType(MapPOIItem.MarkerType.RedPin); // 기본으로 제공하는 BluePin 마커 모양.
        //marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.
        mapView.addPOIItem(marker);

        routeNumber=1;
    }
    private LocationListener mLocationListener = new LocationListener() {
        // 위치가 갱신되면 이벤트 발생
        @Override
        public void onLocationChanged(Location location) {
            Log.e("test", "onLocationChanged, location:" + location);
            double longitude = location.getLongitude(); //경도
            double latitude = location.getLatitude();   //위도
            double altitude = location.getAltitude();   //고도
            float accuracy = location.getAccuracy();    //정확도
            String provider = location.getProvider();   //위치제공자
            show.setText("위치정보 : " + provider + "\n위도 : " + longitude + "\n경도 : " + latitude
                    + "\n고도 : " + altitude + "\n정확도 : "  + accuracy);

            // 현재 위치로 기준 옮김
            // mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(latitude, longitude), true);

            // 모든 마커 제거
            //mapView.removeAllPOIItems();
            //mapView.refreshMapTiles();

            // 현재 위치 표시
//            MapPOIItem marker = new MapPOIItem();
//            marker.setItemName("Default Marker");
//            marker.setTag(0);
//            marker.setMapPoint(MapPoint.mapPointWithGeoCoord(latitude, longitude));
//            marker.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
//            marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.
//            mapView.addPOIItem(marker);

            //이동 경로 표시
            MapPOIItem routeMarker = new MapPOIItem();
            routeMarker.setItemName("");
            routeMarker.setTag(routeNumber++);
            routeMarker.setShowCalloutBalloonOnTouch(false);// 말풍선 기능 해제
            //routeMarker.setCustomImageAutoscale(false);
            routeMarker.setMapPoint(MapPoint.mapPointWithGeoCoord(latitude, longitude));
            routeMarker.setMarkerType(MapPOIItem.MarkerType.CustomImage); // 커스텀 마커
            routeMarker.setCustomImageResourceId(R.drawable.red_marker);
            //marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.
            mapView.addPOIItem(routeMarker);
            showItems();
        }

        // 위치제공자의 상태가 변경되면 이벤트 발생
        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        // 위치제공자 활성화
        @Override
        public void onProviderEnabled(String s) {

        }

        // 위치제공자 비활성화
        @Override
        public void onProviderDisabled(String s) {

        }
    };
    private void getAppKeyHash() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md;
                md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String something = new String(Base64.encode(md.digest(), 0));
                Log.e("Hash key", something);
            }
        } catch (Exception e) {
            Log.e("name not found", e.toString());
        }
    }

    @Override
    public void onMapViewInitialized(MapView mapView) {
        Log.e("initialized", "MapView had loaded.");

//        GpsInfo info = new GpsInfo(this);
//        double lat = info.getLatitude();
//        double lng = info.getLongitude();

        //mapView.setMapCenterPointAndZoomLevel(
        //        MapPoint.mapPointWithGeoCoord(37.57593689999999, 126.97681569999997), 2, true);

//        mapView.setMapCenterPointAndZoomLevel(
//                MapPoint.mapPointWithGeoCoord(lat, lng), 3, true);

        MapPOIItem marker = new MapPOIItem();
        marker.setItemName(getText(R.string.startSpot).toString());
        //marker.setTag(0);
        marker.setShowDisclosureButtonOnCalloutBalloon(false);
        marker.setMapPoint(MapPoint.mapPointWithGeoCoord(37.57593689999999, 126.97681569999997));
        marker.setMarkerType(MapPOIItem.MarkerType.RedPin); // 기본으로 제공하는 BluePin 마커 모양.
        //marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker);
    }

    @Override
    public void onMapViewCenterPointMoved(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewZoomLevelChanged(MapView mapView, int i) {

    }

    @Override
    public void onMapViewSingleTapped(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDoubleTapped(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewLongPressed(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragStarted(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragEnded(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewMoveFinished(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onDaumMapOpenAPIKeyAuthenticationResult(MapView mapView, int i, String s) {
        Log.e("apikey_authentication",
                String.format("Open API Key Authentication Result : code=%d, message=%s", i, s));
    }

    public void checkPermissions() {
        String[] permissions = {
                Manifest.permission.ACCESS_FINE_LOCATION
        };

        int permissionCheck = PackageManager.PERMISSION_GRANTED;
        for (int i = 0; i < permissions.length; i++) {
            permissionCheck = ContextCompat.checkSelfPermission(this, permissions[i]);
            if (permissionCheck == PackageManager.PERMISSION_DENIED) {
                break;
            }
        }

        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            //Toast.makeText(this, "권한 있음", Toast.LENGTH_LONG).show();
        } else {
            //Toast.makeText(this, "권한 없음", Toast.LENGTH_LONG).show();

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[0])) {
                //Toast.makeText(this, "권한 설명 필요함.", Toast.LENGTH_LONG).show();
            } else {
                ActivityCompat.requestPermissions(this, permissions, 1);
            }
        }
    }

    @Override
    public void onPOIItemSelected(MapView mapView, MapPOIItem mapPOIItem) {
        String itemName = mapPOIItem.getItemName();
        Button handle = findViewById(R.id.handle);
        TextView content_text = findViewById(R.id.content_text);
        SlidingDrawer slidingdrawer = findViewById(R.id.slidingdrawer);
        slidingdrawer.close();

        selectedMarker = itemName;

        // 출발지인 경우 슬라이딩 드로어 오픈 안됨
        if (!itemName.equals(getText(R.string.startSpot).toString())) {
            slidingdrawer.animateOpen();
            handle.setText(itemName);

            // 가이드 내용 설정
            if (itemName.equals(getText(R.string.kb_place1).toString())) {
                content_text.setText(getText(R.string.kb_place1_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place2).toString())) {
                content_text.setText(getText(R.string.kb_place2_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place3).toString())) {
                content_text.setText(getText(R.string.kb_place3_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place4).toString())) {
                content_text.setText(getText(R.string.kb_place4_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place5).toString())) {
                content_text.setText(getText(R.string.kb_place5_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place6).toString())) {
                content_text.setText(getText(R.string.kb_place6_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place9).toString())) {
                content_text.setText(getText(R.string.kb_place9_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place10).toString())) {
                content_text.setText(getText(R.string.kb_place10_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place11).toString())) {
                content_text.setText(getText(R.string.kb_place11_text).toString());
            } else if (itemName.equals(getText(R.string.kb_place12).toString())) {
                content_text.setText(getText(R.string.kb_place12_text).toString());
            }

        } else {
            handle.setText(getText(R.string.guide).toString());
            content_text.setText(getText(R.string.guide_text).toString());
        }
    }

    @Override
    public void onCalloutBalloonOfPOIItemTouched(MapView mapView, MapPOIItem mapPOIItem) {

    }

    @Override
    public void onCalloutBalloonOfPOIItemTouched(MapView mapView, MapPOIItem mapPOIItem, MapPOIItem.CalloutBalloonButtonType calloutBalloonButtonType) {

    }

    @Override
    public void onDraggablePOIItemMoved(MapView mapView, MapPOIItem mapPOIItem, MapPoint mapPoint) {

    }
}
